var Dialog = require('../index');


var dialog = new Dialog();
dialog.init();
dialog.say('It works');

